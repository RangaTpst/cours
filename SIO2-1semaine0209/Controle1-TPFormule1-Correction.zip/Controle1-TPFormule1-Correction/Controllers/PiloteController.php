<?php

namespace App\Controllers;

use \App\Models\Pilote;
use \App\Controllers\ValidationController;

class PiloteController extends Controller
{
    public function create($record): void
    {
        //$record = implode('\', \'', array_values($record));

        $pilote = new Pilote();
        $validation = new ValidationController();

        $pilote->insertPilote($record);
        $pilote->setNumero($record[0]);
        $pilote->setNom($record[1]);
        $pilote->setIDEcurie($record[2]);
        $pilote->setNationalite($record[3]);
        $pilote->setAge($record[4]);
        $pilote->setPhoto($record[5]);

        $nameSuccess = "New Pilote was created successfully!";
        $validation->tagSuccess($nameSuccess);

    }

    public function read():void
    {
        $pilote = new Pilote();
        $validation = new ValidationController();

        $pilote->list();        

        $nameSuccess = "Pilote list was displayed successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function deliverPack():array
    {
        $pilote = new Pilote();
        //$validation = new ValidationController();

        return $pilote->pack();        
    }

    /**
     * Chercher une pilote par ID
     */ 
    public function findByID($criteria):array
    {
        $pilote = new Pilote();

        return $pilote->findPilote('id', $criteria);
    }

    /**
     * Chercher une pilote par Nom
     */ 
    public function findByType($criteria):array
    {
        $pilote = new Pilote();

        return $pilote->findPilote('nom', $criteria);
    }

    public function update($column, $change, $columnCriteria, $criteria): void
    {
        $pilote = new Pilote();
        $validation = new ValidationController();

        $pilote->modifyPilote($column, $change, $columnCriteria, $criteria);      
        
        $nameSuccess = "Pilote was updated successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function delete($column, $criteria): void
    {
        $pilote = new Pilote();
        $validation = new ValidationController();
        $pilote->deletePilote($column, $criteria);        
        $nameSuccess = "Pilote was unsubscribed successfully!";
        $validation->tagSuccess($nameSuccess);
    }
}