<?php

namespace App\Controllers;

use \App\Models\Voiture;
use \App\Controllers\ValidationController;

class VoitureController extends Controller
{
    public function create($record): void
    {
        //$record = implode('\', \'', array_values($record));

        $voiture = new Voiture();
        $validation = new ValidationController();

        $voiture->insertVoiture($record);
        $voiture->setPoids($record[0]);        
        $voiture->setPuissance($record[1]);
        $voiture->setMoteur($record[2]);
        $voiture->setPhoto($record[3]);

        $nameSuccess = "New Voiture was created successfully!";
        $validation->tagSuccess($nameSuccess);

    }

    public function read():void
    {
        $voiture = new Voiture();
        $validation = new ValidationController();

        $voiture->list();        

        $nameSuccess = "Voiture list was displayed successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function deliverPack():array
    {
        $voiture = new Voiture();
        $validation = new ValidationController();

        return $voiture->pack();        
    }

    /**
     * Chercher une voiture par ID
     */ 
    public function findByID($criteria):array
    {
        $voiture = new Voiture();

        return $voiture->findVoiture('id', $criteria);
    }

    /**
     * Chercher une voiture par Moteur
     */ 
    public function findByType($criteria):array
    {
        $voiture = new Voiture();

        return $voiture->findVoiture('moteur', $criteria);
    }

    public function update($column, $change, $columnCriteria, $criteria): void
    {
        $voiture = new Voiture();
        $validation = new ValidationController();

        $voiture->modifyVoiture($column, $change, $columnCriteria, $criteria);      
        
        $nameSuccess = "Voiture was updated successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function delete($column, $criteria): void
    {
        $voiture = new Voiture();
        $validation = new ValidationController();
        $voiture->deleteVoiture($column, $criteria);        
        $nameSuccess = "Voiture was unsubscribed successfully!";
        $validation->tagSuccess($nameSuccess);
    }
}