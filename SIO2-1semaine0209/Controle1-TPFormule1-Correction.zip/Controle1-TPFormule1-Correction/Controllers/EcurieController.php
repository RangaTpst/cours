<?php

namespace App\Controllers;

use \App\Models\Ecurie;
use \App\Controllers\ValidationController;

class EcurieController extends Controller
{
    public function create($record): void
    {
        //$record = implode('\', \'', array_values($record));

        $ecurie = new Ecurie();
        $validation = new ValidationController();

        $ecurie->insertEcurie($record);
        $ecurie->setNom($record[0]);
        $ecurie->setPays($record[1]);
        $ecurie->setSponsor($record[2]);
        $ecurie->setIDVoiture($record[3]);
        $ecurie->setBlason($record[4]);

        $nameSuccess = "New Ecurie was created successfully!";
        $validation->tagSuccess($nameSuccess);

    }

    public function read():void
    {
        $ecurie = new Ecurie();
        $validation = new ValidationController();

        $ecurie->list();        

        $nameSuccess = "Ecurie list was displayed successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function deliverPack():array
    {
        $ecurie = new Ecurie();
        //$validation = new ValidationController();

        return $ecurie->pack();        
    }

    /**
     * Chercher une ecurie par ID
     */ 
    public function findByID($criteria):array
    {
        $ecurie = new Ecurie();

        return $ecurie->findEcurie('id', $criteria);
    }

    /**
     * Chercher une ecurie par Nom
     */ 
    public function findByType($criteria):array
    {
        $ecurie = new Ecurie();

        return $ecurie->findEcurie('nom', $criteria);
    }

    public function update($column, $change, $columnCriteria, $criteria): void
    {
        $ecurie = new Ecurie();
        $validation = new ValidationController();

        $ecurie->modifyEcurie($column, $change, $columnCriteria, $criteria);      
        
        $nameSuccess = "Ecurie was updated successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function delete($column, $criteria): void
    {
        $ecurie = new Ecurie();
        $validation = new ValidationController();
        $ecurie->deleteEcurie($column, $criteria);        
        $nameSuccess = "Ecurie was unsubscribed successfully!";
        $validation->tagSuccess($nameSuccess);
    }
}