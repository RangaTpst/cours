<?php

namespace App\Routes;

use App\Controllers\HtmlController;
/**
* Simple example of implementing a route class and declaring __construct
* , then using the navigator method to initialize the menu.
*/
class Web
{
    function __construct()
    {
        $html = new HtmlController();
        
        $html->tagOpen("ul id=\"navigation\"");
        $html->URLlink("/index.php", "Accueil"); 
        $html->URLlink("/Views/ecurie.lame.php", "Ecurie"); 
        $html->URLlink("/Views/pilote.lame.php", "Pilote"); 
        $html->URLlink("/Views/voiture.lame.php", "Voiture");
        $html->URLlink("/Views/voiture_pilote.lame.php", "Voiture & Pilote");
        $html->tagClose("ul"); 
    } 
}