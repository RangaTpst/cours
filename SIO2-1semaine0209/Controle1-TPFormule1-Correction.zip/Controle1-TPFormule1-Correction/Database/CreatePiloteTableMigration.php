<?php

namespace App\Database;

include_once( __DIR__ . '/Database.php');

 $db = new Database();

    $db->exec('CREATE TABLE pilotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero INTEGER NOT NULL ,
        nom VARCHAR NOT NULL ,
        id_ecurie INTEGER NOT NULL ,
        nationalite VARCHAR NOT NULL ,
        age INTEGER NOT NULL ,
        photo VARCHAR NOT NULL ,
        FOREIGN KEY(id_ecurie) REFERENCES ecuries(id) ON DELETE CASCADE
    )');