<?php

namespace App\Database;

include_once( __DIR__ . '/Database.php');

 $db = new Database();

    $db->exec('CREATE TABLE ecuries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom VARCHAR NOT NULL ,
        pays VARCHAR NOT NULL ,
        sponsor VARCHAR NOT NULL ,
        id_voiture INTEGER NOT NULL ,
        blason VARCHAR NOT NULL,
        FOREIGN KEY(id_voiture) REFERENCES voitures(id) ON DELETE CASCADE
    )');