<?php

namespace App\Database;

include_once( __DIR__ . '/Database.php');

 $db = new Database();

    $db->exec('CREATE TABLE voitures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        poids INTEGER NOT NULL ,
        puissance INTEGER NOT NULL ,
        moteur VARCHAR NOT NULL ,
        photo VARCHAR NOT NULL
    )');