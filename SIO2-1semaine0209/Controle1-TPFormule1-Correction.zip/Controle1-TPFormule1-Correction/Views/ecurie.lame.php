<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\EcurieController;
use App\Controllers\VoitureController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;
use App\Controllers\ValidationController;
use App\Routes\Web;

$ecurie = new EcurieController();
$voiture = new VoitureController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
$validation = new ValidationController();

$deliveredVoiture = $voiture->deliverPack();

$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Ecuries");
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div");

      echo '<br/>';
        echo '<h3>Créer une Ecurie:</h3><br/><br/>';
          $form->openForm($_SERVER["PHP_SELF"], "POST");
          $form->tagLabel("nom","Entrer le Nom de l'Ecurie:");
          $form->tagInputText("nom", "nom", "Nom de l'Ecurie Ici");
          $form->tagLabel("pays","Entrer le Pays de la nouvelle Ecurie:");
          $form->tagInputText("pays", "pays", "Pays de l'Ecurie Ici");
          $form->tagLabel("sponsor","Entrer le Sponsor de la nouvelle Ecurie:");
          $form->tagInputText("sponsor", "sponsor", "Sponsor de l'Ecurie Ici");

          $form->tagLabel("id_voiture","Voiture de l'Ecurie:");

          $form->tagSelect("id_voiture");

          foreach($deliveredVoiture as $option)
          {
            $value = $option['id'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
          $form->closeSelect();

          echo '<br/><br/>';

          $form->tagLabel("blason","Entrer le Blason de la nouvelle Ecurie:");
          $form->tagInputFile("blason", "blason");

          $form->submit("submitBtn", "Créer");
          $form->closeForm();

          if(isset($_POST['submitBtn'])) {
            
            if($validation->validate("nom") == true && $validation->validate("pays") == true && $validation->validate("sponsor") == true)
            {
              $record = array($_POST['nom'],$_POST['pays'],$_POST['sponsor'],$_POST['id_voiture'], $_FILES["blason"]["name"]);
                //var_dump($record);
                //var_dump($_FILES["blason"]["tmp_name"]);

                $ecurie->create($record);  

                $temp_file = $_FILES["blason"]["tmp_name"];
                $target_dir = "../storage/";
                $target_file = $target_dir . basename($_FILES["blason"]["name"]);
                
                move_uploaded_file($temp_file, $target_file);              
            }  
          }
            echo '<br/>';

        echo '<h3>Afficher tous les Ecuries:</h3><br/>';
        $ecurie->read();
        echo '<br/>';

        $delivered = $ecurie->deliverPack();

        echo '<br/>';


        echo '<h3>Mettre à Jour une Ecurie:</h3><br/><br/>';

        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("changeEcurie","Modifier l'ecurie:");
  
          $form->tagSelect("selectEcurie");
  
          foreach($delivered as $option)
          {
            $value = $option['id'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
  
          $form->closeSelect();
          echo '<br/>';
  
        $form->tagInputText("nom", "nom", "Modifier le Nom Ici");
        $form->tagInputText("pays", "pays", "Modifier le Pays Ici");
        $form->tagInputText("sponsor", "sponsor", "Modifier le Sponsor Ici");
        $form->tagLabel("id_voiture","Modifier la Voiture Ici:");
        $form->tagSelect("id_voiture");

        foreach($deliveredVoiture as $option)
        {
          $value = $option['id'];
          $astring = implode(',', $option);
          $form->tagOptionValue("option", $value, $astring, false);
        }
        $form->closeSelect();
        echo '<br/>';
        
        $form->tagLabel("blason","Modifier le Blason de la nouvelle Ecurie:");
        $form->tagInputFile("blason", "blason");

        $form->submit("modifyBtn", "Modifier");

        $form->closeForm();      
  
        if(isset($_POST['modifyBtn'])) {
  
          if($validation->validate("nom") == true && $validation->validate("pays") == true && $validation->validate("sponsor") == true)
          {
  
            $selectRecord = $_POST['selectEcurie'];
  
            $changeNom = $_POST['nom'];  
            $changePays = $_POST['pays'];  
            $changeSponsor = $_POST['sponsor'];  
            $changeIDVoiture = $_POST['id_voiture'];
            $changeBlason = $_FILES['blason']['name'];

            $ecurie->update("nom", $changeNom, "id", $selectRecord);
            $ecurie->update("pays", $changePays, "id", $selectRecord);
            $ecurie->update("sponsor", $changeSponsor, "id", $selectRecord);
            $ecurie->update("id_voiture", $changeIDVoiture, "id", $selectRecord);
            $ecurie->update("blason", $changeBlason, "id", $selectRecord);

            $temp_file = $_FILES["blason"]["tmp_name"];
            $target_dir = "../storage/";
            $target_file = $target_dir . basename($_FILES["blason"]["name"]);
            
            move_uploaded_file($temp_file, $target_file); 
          }
        }

        echo '<h3>Supprimer une Ecurie:</h3><br/><br/>';


        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("deleteEcurie","Supprimer l'Ecurie:");
        $form->tagSelect("deleteEcurie");

        foreach($delivered as $option)
        {
          $value = $option['id'];
          $astring = implode(',', $option);
          $form->tagOptionValue("option", $value, $astring, false);
        }
        $form->closeSelect();
        
        $form->submit("deleteBtn", "Supprimer");
        $form->closeForm();
        
        if(isset($_POST['deleteBtn'])) {

          $id = $_POST['deleteEcurie'];

        //  echo $id;

          $ecurie->delete("id", $id);
        }
      
        echo '<br/>';

    $html->tagClose('div');
  $html->tagClose('body');
$html->tagClose('html');