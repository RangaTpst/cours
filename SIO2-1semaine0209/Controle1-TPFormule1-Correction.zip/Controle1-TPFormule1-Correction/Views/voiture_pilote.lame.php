<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\PiloteController;
use App\Controllers\VoitureController;
use App\Controllers\EcurieController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\ValidationController;
use App\Routes\Web;

$pilote = new PiloteController();
$ecurie = new EcurieController();
$voiture = new VoitureController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$validation = new ValidationController();

$deliveredEcurie = $ecurie->deliverPack();
$deliveredVoiture = $voiture->deliverPack();
$delivered = $pilote->deliverPack();

$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Voitures & Pilotes");
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div");

        echo '<h3>Afficher tous les pilotes et leurs voitures respectives:</h3><br/>';
       // $pilote->read();
        echo '<br/>';
//        $id_ecurie = "";
//        $photo_pilote = "";        
//        $photo_voiture = "";
        $html->tagOpen("table");

            foreach($delivered as $option)
            {
              $value = $option['id'];
              $astring = implode(',', $option);
              echo '<br/>';
              $id_ecurie =  $option['id_ecurie'];
              $photo_pilote = $option['photo'];
              $my_ecurie = $ecurie->findByID($id_ecurie);
              $my_voiture = $voiture->findByID($my_ecurie['id_voiture']);  
              $photo_voiture =  $my_voiture['photo'];

              $html->tagOpen("tr");
                $html->tagOpen("td");
                  echo  "<img src=/storage/" . $photo_pilote . " alt=\"Image here: \" width=\"150\" height=\"auto\">"  . "<br/>";
                $html->tagClose("td");      
                $html->tagOpen("td");                
                  echo  "<img src=/storage/" . $photo_voiture . " alt=\"Image here: \" width=\"150\" height=\"auto\">"  . "<br/>";
                $html->tagClose("td");
              $html->tagClose("tr");
            }
          $html->tagClose("table");
        echo '<br/>';
      $html->tagClose('div');
  $html->tagClose('body');
$html->tagClose('html');
        