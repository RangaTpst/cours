<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\PiloteController;
use App\Controllers\EcurieController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;
use App\Controllers\ValidationController;
use App\Routes\Web;

$pilote = new PiloteController();
$ecurie = new EcurieController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
$validation = new ValidationController();

$deliveredEcurie = $ecurie->deliverPack();

$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Pilotes");
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div");

        echo '<br/>';
        echo '<h3>Créer un Pilote:</h3><br/><br/>';
          $form->openForm($_SERVER["PHP_SELF"], "POST");
          $form->tagLabel("numero","Entrer le Numero du Pilote:");
          $form->tagInputText("numero", "numero", "Numero du Pilote Ici");
          $form->tagLabel("nom","Entrer le Nom du Pilote:");
          $form->tagInputText("nom", "nom", "Nom du Pilote Ici");

          $form->tagLabel("id_ecurie","Ecurie du Pilote:");

          $form->tagSelect("id_ecurie");

          foreach($deliveredEcurie as $option)
          {
            $value = $option['id'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
          $form->closeSelect();

          echo '<br/><br/>';

          $form->tagLabel("nationalite","Entrer la Nationalite du Pilote:");
          $form->tagInputText("nationalite", "nationalite", "Nationalite du Pilote Ici");

          $form->tagLabel("age","Entrer l'Age du Pilote:");
          $form->tagInputText("age", "age", "Age du Pilote Ici");

          $form->tagLabel("photo","Entrer la Photo du Pilote:");
          $form->tagInputFile("photo", "photo");

          $form->submit("submitBtn", "Créer");
          $form->closeForm();

          if(isset($_POST['submitBtn'])) {

            if($validation->validate("numero") == true && $validation->validate("nom") == true)
            {
              $record = array($_POST['numero'],$_POST['nom'],$_POST['id_ecurie'],$_POST['nationalite'],$_POST['age'],$_FILES["photo"]["name"]);
              $pilote->create($record);

              $temp_file = $_FILES["photo"]["tmp_name"];
              $target_dir = "../storage/";
              $target_file = $target_dir . basename($_FILES["photo"]["name"]);
              
              move_uploaded_file($temp_file, $target_file);              
            }
          }
            echo '<br/>';

        echo '<h3>Afficher toutes les pilotes:</h3><br/>';
        $pilote->read();
        echo '<br/>';


        $delivered = $pilote->deliverPack();

        echo '<br/>';
  
        echo '<h3>Mettre à Jour un Pilote:</h3><br/><br/>';

          $form->openForm($_SERVER["PHP_SELF"], "POST");
          $form->tagLabel("changePilote","Modifier le pilote:");

            $form->tagSelect("selectPilote");

            foreach($delivered as $option)
            {
              $value = $option['id'];
              $astring = implode(',', $option);
              $form->tagOptionValue("option", $value, $astring, false);
            }

            $form->closeSelect();
            echo '<br/>';

            $form->tagInputText("numero", "numero", "Modifier le Numero Ici");
            $form->tagInputText("nom", "nom", "Modifier le Nom Ici");
            $form->tagLabel("id_ecurie","Modifier l'Ecurie' Ici:");
            $form->tagSelect("id_ecurie");
    
            foreach($deliveredEcurie as $option)
            {
              $value = $option['id'];
              $astring = implode(',', $option);
              $form->tagOptionValue("option", $value, $astring, false);
            }
            $form->closeSelect();
            echo '<br/>';

            $form->tagInputText("nationalite", "nationalite", "Modifier la Nationalité Ici");
            $form->tagInputText("age", "age", "Modifier l'Age Ici");

            $form->tagLabel("photo","Modifier la Photo du Pilote:");
            $form->tagInputFile("photo", "photo");
    
            $form->submit("modifyBtn", "Modifier");
          $form->closeForm();      

          if(isset($_POST['modifyBtn'])) {

            if($validation->validate("numero") == true && $validation->validate("nom") == true)
            {
    
              $selectRecord =$_POST['selectPilote'];
    
              $changeNumero = $_POST['numero'];  
              $changeNom = $_POST['nom'];  
              $changeIDEcurie = $_POST['id_ecurie'];  
              $changeNationalite = $_POST['nationalite'];
              $changeAge = $_POST['age'];
              $changePhoto = $_FILES['photo']['name'];
  
              $pilote->update("numero", $changeNumero, "id", $selectRecord);
              $pilote->update("nom", $changeNom, "id", $selectRecord);
              $pilote->update("id_ecurie", $changeIDEcurie, "id", $selectRecord);
              $pilote->update("nationalite", $changeNationalite, "id", $selectRecord);
              $pilote->update("age", $changeAge, "id", $selectRecord);
              $pilote->update("photo", $changePhoto, "id", $selectRecord);
  
              $temp_file = $_FILES["photo"]["tmp_name"];
              $target_dir = "../storage/";
              $target_file = $target_dir . basename($_FILES["photo"]["name"]);
              
              move_uploaded_file($temp_file, $target_file); 
            }  
          }
            echo '<br/>';

            echo '<h3>Supprimer un Pilote:</h3><br/><br/>';

            $form->openForm($_SERVER["PHP_SELF"], "POST");
            $form->tagLabel("deletePilote","Supprimer le pilote:");
            $form->tagSelect("deletePilote");

            foreach($delivered as $option)
            {
              $value = $option['id'];
              $astring = implode(',', $option);
              $form->tagOptionValue("option", $value, $astring, false);
            }

            $form->closeSelect();
            $form->submit("deleteBtn", "Supprimer");
            $form->closeForm();
  
            if(isset($_POST['deleteBtn'])) {
              $id = $_POST['deletePilote'];
              //var_dump($id);
              $pilote->delete("id", $id);
            }
          
            echo '<br/>';
          $html->tagClose('div');
        $html->tagClose('body');
      $html->tagClose('html');
        