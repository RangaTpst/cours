<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\VoitureController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;
use App\Controllers\ValidationController;
use App\Routes\Web;

$voiture = new VoitureController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
$validation = new ValidationController();
$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Voitures");
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div");

      echo '<br/>';
        echo '<h3>Créer une Voiture:</h3><br/><br/>';
          $form->openForm($_SERVER["PHP_SELF"], "POST");

          $form->tagLabel("poids","Entrer le Poids de la  nouvelle Voiture:");
          $form->tagInputText("poids", "poids", "Poids de la Voiture Ici");

          $form->tagLabel("puissance","Entrer la Puissance de la  nouvelle Voiture:");
          $form->tagInputText("puissance", "puissance", "Puissance de la Voiture Ici");

          $form->tagLabel("moteur","Entrer le Moteur de la  nouvelle Voiture:");
          $form->tagInputText("moteur", "moteur", "Moteur de la Voiture Ici");

          $form->tagLabel("photo","Entrer la Photo de la nouvelle Voiture:");
          $form->tagInputFile("photo", "photo");
  
          $form->submit("submitBtn", "Créer");
          $form->closeForm();

          if(isset($_POST['submitBtn'])) {
            
            if($validation->validate("moteur") == true)
            {
              $record = array($_POST['poids'], $_POST['puissance'], $_POST['moteur'], $_FILES['photo']["name"]);
                //var_dump($record);
              $voiture->create($record);

              $temp_file = $_FILES["photo"]["tmp_name"];
              $target_dir = "../storage/";
              $target_file = $target_dir . basename($_FILES["photo"]["name"]);
              
              move_uploaded_file($temp_file, $target_file);              
            }
          }
            echo '<br/>';

        echo '<h3>Afficher toutes les Voitures:</h3><br/>';
        $voiture->read();
        echo '<br/>';

        $delivered = $voiture->deliverPack();

        echo '<br/>';

        echo '<h3>Mettre à Jour une Voiture:</h3><br/><br/>';

        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("changeVoiture","Modifier la Voiture:");
  
          $form->tagSelect("selectVoiture");
  
          foreach($delivered as $option)
          {
            $value = $option['id'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
  
          $form->closeSelect();
          echo '<br/>';
  
        $form->tagInputText("poids", "poids", "Modifier le Poids de la Voiture Ici");
        $form->tagInputText("puissance", "puissance", "Modifier la Puissance de la Voiture Ici");
        $form->tagInputText("moteur", "moteur", "Modifier le Moteur de la Voiture Ici");
        $form->tagLabel("photo","Modifier la Photo de la nouvelle Voiture:");
        $form->tagInputFile("photo", "photo");

        $form->submit("modifyBtn", "Modifier");
        $form->closeForm();      
  
        if(isset($_POST['modifyBtn'])) {
  
          if($validation->validate("moteur") == true)
          {
  
            $selectRecord =$_POST['selectVoiture'];  
  
            $changePoids = $_POST['poids'];  
            $changePuissance = $_POST['puissance'];
            $changeMoteur = $_POST['moteur'];
            $changePhoto = $_FILES['photo']['name'];

            $voiture->update("poids", $changePoids, "id", $selectRecord);
            $voiture->update("puissance", $changePuissance, "id", $selectRecord);
            $voiture->update("moteur", $changeMoteur, "id", $selectRecord);
            $voiture->update("photo", $changePhoto, "id", $selectRecord);
            
            $temp_file = $_FILES["photo"]["tmp_name"];
            $target_dir = "../storage/";
            $target_file = $target_dir . basename($_FILES["photo"]["name"]);
            
            move_uploaded_file($temp_file, $target_file); 
          }
        }

        echo '<h3>Supprimer une Voiture:</h3><br/><br/>';


        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("deleteVoiture","Supprimer la Voiture:");
        $form->tagSelect("deleteVoiture");

        foreach($delivered as $option)
        {
          $value = $option['id'];
          $astring = implode(',', $option);
          $form->tagOptionValue("option", $value, $astring, false);
        }
        $form->closeSelect();
        
        $form->submit("deleteBtn", "Supprimer");
        $form->closeForm();
        
        if(isset($_POST['deleteBtn'])) {

          $id = $_POST['deleteVoiture'];

        //  echo $id;

          $voiture->delete("id", $id);
        }
      
        echo '<br/>';

    $html->tagClose('div');
  $html->tagClose('body');
$html->tagClose('html');
