<?php

namespace App\Models;

use App\Database\Database;

define("ECURIES", "ecuries");

/**
 * Classe Ecurie
 */ 
class Ecurie extends Model
{

    /**
     * Attribut Nom de l'Ecurie
     */ 
    private $nom;

    /**
     * Attribut Pays de l'Ecurie
     */ 
    private $pays;

    /**
     * Attribut Sponsor de l'Ecurie
     */ 
    private $sponsor;

    /**
     * Attribut Identifiant Voiture de l'Ecurie
     */ 
    private $id_voiture;

    /**
     * Attribut Blason de l'Ecurie
     */ 
    private $blason;


    /**
     * Constructeur de l'Ecurie
     */ 
    public function __construct()
    {

    }

    /**
     * Afficher la liste des Ecuries
     */ 
    public function list()
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        $this->all(ECURIES, $attributes);
    }

    /**
     * Mettre à disposition les Ecuries dans une array
     */ 
    public function pack():array
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        return $this->packAll(ECURIES, $attributes);
    }

    /**
     * Insérer une Ecurie
     */ 
    public function insertEcurie($records)
    {
        $attributes = get_class_vars(get_class($this));
        $this->insert(ECURIES, $attributes, $records);
    }

    /**
     * Chercher une Ecurie
     */ 
    public function findEcurie($column, $criteria)
    {
        $result = $this->find(ECURIES, $column, $criteria);
        return $result;
    }

    /**
     * Modifier le champ d'une Ecurie
     */ 
    public function modifyEcurie($column, $change, $columnCriteria, $criteria)
    {
        $this->update(ECURIES, $column, $change, $columnCriteria, $criteria);

        //print_r($result);
    }

    /**
     * Supprimer une Ecurie
     */ 
    public function deleteEcurie($column, $criteria)
    {
        $this->delete(ECURIES, $column, $criteria);
    }

    /**
     * Obtenir la valeur du Nom
     */ 
	public function getNom(): string
	{
		return $this->nom;
	}

    /**
     * Obtenir la valeur du Pays
     */ 
	public function getPays(): string
	{
		return $this->pays;
	}

    /**
     * Obtenir la valeur du Sponsor
     */ 
	public function getSponsor(): string
	{
		return $this->sponsor;
	}

    /**
     * Obtenir la valeur de l'Identifiant Voiture 
     */ 
	public function getIDVoiture(): int
	{
		return $this->id_voiture;
	}

    /**
     * Obtenir la valeur du Blason
     */ 
	public function getBlason(): string
	{
		return $this->blason;
	}

    /**
     * Configurer la valeur du Nom
     */ 
	public function setNom($nom): void
	{
		$this->nom = $nom;
	}

    /**
     * Configurer la valeur du Pays
     */ 
	public function setPays($pays): void
	{
		$this->pays = $pays;
	}

    /**
     * Configurer la valeur du Sponsor
     */ 
	public function setSponsor($sponsor): void
	{
		$this->sponsor = $sponsor;
	}

    /**
     * Configurer la valeur de l'Identifiant voiture
     */ 
	public function setIDVoiture($id_voiture): void
	{
		$this->id_voiture = $id_voiture;
	}

    /**
     * Configurer la valeur de la Description
     */ 
	public function setBlason($blason): void
	{
		$this->blason = $blason;
	}
}