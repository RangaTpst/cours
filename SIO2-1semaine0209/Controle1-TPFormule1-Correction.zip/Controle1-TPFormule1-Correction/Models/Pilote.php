<?php

namespace App\Models;

use App\Database\Database;

define("PILOTES", "pilotes");


/**
 * Classe Article
 */ 
class Pilote extends Model
{
    /**
     * Attribut Numero
     */ 
    private $numero;

    /**
     * Attribut Nom
     */ 
    private $nom;

    /**
     * Attribut Identifiant de l'Ecurie
     */ 
    private $id_ecurie;

    /**
     * Attribut Nationalité
     */ 
    private $nationalite;

    /**
     * Attribut Age
     */ 
    private $age;

    /**
     * Attribut Photo
     */ 
    private $photo;


    /**
     * Constructeur de Pilote
     */ 
    public function __construct()
    {

    }

    /**
     * Afficher la liste des Pilotes
     */ 
    public function list()
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        $this->all(PILOTES, $attributes);
    }

    /**
     * Mettre à disposition les Pilotes dans une array
     */ 
    public function pack():array
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        return $this->packAll(PILOTES, $attributes);
    }

    /**
     * Insérer un Pilote
     */ 
    public function insertPilote($records)
    {
        $attributes = get_class_vars(get_class($this));
        $this->insert(PILOTES, $attributes, $records);
    }

    /**
     * Chercher un Pilote
     */ 
    public function findPilote($column, $criteria)
    {
        $result = $this->find(PILOTES, $column, $criteria);
        return $result;
    }

    /**
     * Modifier le champ d'un Pilote
     */ 
    public function modifyPilote($column, $change, $columnCriteria, $criteria)
    {
        $this->update(PILOTES, $column, $change, $columnCriteria, $criteria);

        //print_r($result);
    }

    /**
     * Supprimer un Pilote
     */ 
    public function deletePilote($column, $criteria)
    {
        $this->delete(PILOTES, $column, $criteria);
    }

    /**
     * Obtenir la valeur du Numero
     */ 
	public function getNumero(): int
	{
		return $this->numero;
	}

    /**
     * Obtenir la valeur du Nom
     */ 
	public function getNom(): string
	{
		return $this->nom;
	}

    /**
     * Obtenir la valeur de l'Identifiant d'Ecurie'
     */ 
	public function getIDEcurie(): int
	{
		return $this->id_ecurie;
	}

    /**
     * Obtenir la valeur de la Nationalité
     */ 
	public function getNationalite(): string
	{
		return $this->nationalite;
	}

    /**
     * Obtenir la valeur de l'Age
     */ 
	public function getAge(): int
	{
		return $this->age;
	}

    /**
     * Obtenir la valeur de la Photo
     */ 
	public function getPhoto(): string
	{
		return $this->photo;
	}

    /**
     * Configurer la valeur du Numero
     */ 
	public function setNumero($numero): void
	{
		$this->numero = $numero;
	}

    /**
     * Configurer la valeur du Nom
     */ 
	public function setNom($nom): void
	{
		$this->nom = $nom;
	}

    /**
     * Configurer la valeur de l'Identifiant de l'Ecurie'
     */ 
	public function setIDEcurie($id_ecurie): void
	{
		$this->id_ecurie = $id_ecurie;
	}

    /**
     * Configurer la valeur de la Nationalité
     */ 
	public function setNationalite($nationalite): void
	{
		$this->nationalite = $nationalite;
	}

    /**
     * Configurer la valeur de l'Age'
     */ 
	public function setAge($age): void
	{
		$this->age = $age;
	}

    /**
     * Configurer la valeur de la Photo
     */ 
	public function setPhoto($photo): void
	{
		$this->photo = $photo;
	}
}