<?php

namespace App\Models;

use App\Database\Database;

define("VOITURES", "voitures");


/**
 * Classe Article
 */ 
class Voiture extends Model
{
    /**
     * Attribut Poids
     */ 
    private $poids;

    /**
     * Attribut Puissance
     */ 
    private $puissance;

    /**
     * Attribut Moteur
     */ 
    private $moteur;

    /**
     * Attribut Photo
     */ 
    private $photo;


    /**
     * Constructeur de la Voiture'
     */ 
    public function __construct()
    {

    }

    /**
     * Afficher la liste des voitures
     */ 
    public function list()
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        $this->all(VOITURES, $attributes);
    }

    /**
     * Mettre à disposition les Voitures dans une array
     */ 
    public function pack():array
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        return $this->packAll(VOITURES, $attributes);
    }

    /**
     * Insérer une Voiture
     */ 
    public function insertVoiture($records)
    {
        $attributes = get_class_vars(get_class($this));
        $this->insert(VOITURES, $attributes, $records);
    }

    /**
     * Chercher une Voiture
     */ 
    public function findVoiture($column, $criteria)
    {
        $result = $this->find(VOITURES, $column, $criteria);
        return $result;
    }

    /**
     * Modifier le champ d'une Voiture
     */ 
    public function modifyVoiture($column, $change, $columnCriteria, $criteria)
    {
        $this->update(VOITURES, $column, $change, $columnCriteria, $criteria);

        //print_r($result);
    }

    /**
     * Supprimer une Voiture
     */ 
    public function deleteVoiture($column, $criteria)
    {
        $this->delete(VOITURES, $column, $criteria);
    }

    /**
     * Obtenir la valeur du Poids
     */ 
	public function getPoids(): int
	{
		return $this->poids;
	}

    /**
     * Obtenir la valeur de la Puissance
     */ 
	public function getPuissance(): int
	{
		return $this->puissance;
	}

    /**
     * Obtenir la valeur du Moteur 
     */ 
	public function getMoteur(): string
	{
		return $this->moteur;
	}

    /**
     * Obtenir la valeur de la Photo
     */ 
	public function getPhoto(): string
	{
		return $this->photo;
	}

    /**
     * Configurer la valeur du Poids
     */ 
	public function setPoids($poids): void
	{
		$this->poids = $poids;
	}

    /**
     * Configurer la valeur de la Puissance
     */ 
	public function setPuissance($puissance): void
	{
		$this->puissance = $puissance;
	}

    /**
     * Configurer la valeur du Moteur
     */ 
	public function setMoteur($moteur): void
	{
		$this->moteur = $moteur;
	}

    /**
     * Configurer la valeur de la Photo
     */ 
	public function setPhoto($photo): void
	{
		$this->photo = $photo;
	}
}